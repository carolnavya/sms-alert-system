import json
import boto3
import traceback
from botocore.exceptions import ClientError
import trackerDB
import logging


def parseStreamArn(streamARN):
    tableName = streamARN.split(':')[5].split('/')[1]
    return(tableName)
    
def lambda_handler(event, context):
    
    logger = logging.getLogger(__name__)
    db = trackerDB.TrackerDB(logger, None)
    if not db.dynamodb:
        db.dynamodb = db.connect()
    if not db.exists("tracker"):
        print("Does not exist")
        db.createTable("tracker")
            
    records = event["Records"]
    tableName = parseStreamArn(records[0]['eventSourceARN'])
    print(tableName)
    new_record = []
    
    print(records)
    
    for record in records:
        event_name = record['eventName'].upper()
        
        responses =[]

        if (event_name == 'MODIFY'):
            print(event_name, record)
            message_id = record['dynamodb']['Keys']['messageID']['S']
            new_message = record['dynamodb']['NewImage']
            msg_status = new_message['Qstatus']['N']
            try:
                messageTime = new_message['messageTime']['N']
            except:
                messageTime = new_message['messageTime']['S']
            print(msg_status, messageTime)
            if msg_status == "0":
                db.setMessagesFailed()
                db.setMessagesSent()
                db.setAvgTime(messageTime)
            elif msg_status == "1":
                db.setMessagesSent()
                db.setAvgTime(messageTime)
            elif msg_status == "-1":
                responses.append(0)
        elif (event_name == 'REMOVE'):
            responses.append(0)
		
    return {
        'statusCode': 200,
        'body': responses
    }
